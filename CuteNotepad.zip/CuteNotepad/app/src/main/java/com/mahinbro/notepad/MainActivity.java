package com.mahinbro.notepad;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

public class MainActivity extends Activity {
    private WebView webView;

    @SuppressLint({"SetJavaScriptEnabled", "AddJavascriptInterface"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Full immersive mode (hides both status and navigation bars)
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                             WindowManager.LayoutParams.FLAG_FULLSCREEN);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
                             WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED);

        // Enable immersive sticky mode (hides navigation and status bar)
        getWindow().getDecorView().setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_LAYOUT_STABLE
            | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
            | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
            | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
            | View.SYSTEM_UI_FLAG_FULLSCREEN
            | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);

        try {
            webView = new WebView(this);

            // Performance optimization: create with hardware acceleration
            webView.setLayerType(View.LAYER_TYPE_HARDWARE, null);
            setContentView(webView);

            // WebView setup with maximum performance optimizations
            WebSettings webSettings = webView.getSettings();
            webSettings.setJavaScriptEnabled(true);
            webSettings.setDomStorageEnabled(true);
            webSettings.setDatabaseEnabled(true);
            webSettings.setAppCacheEnabled(false); // Disable cache to prevent lag
            webSettings.setCacheMode(WebSettings.LOAD_NO_CACHE);
            webSettings.setRenderPriority(WebSettings.RenderPriority.HIGH);

            // More aggressive performance tweaks
            webView.setHorizontalScrollBarEnabled(false);
            webView.setVerticalScrollBarEnabled(false);
            webSettings.setUseWideViewPort(true);
            webSettings.setLoadWithOverviewMode(true);
            webSettings.setBuiltInZoomControls(false);
            webSettings.setDisplayZoomControls(false);
            webSettings.setSupportZoom(false);
            webSettings.setLayoutAlgorithm(WebSettings.LayoutAlgorithm.NORMAL);

            // Network optimizations
            webSettings.setAllowFileAccess(true);
            webSettings.setAllowContentAccess(true);
            webSettings.setAllowFileAccessFromFileURLs(true);
            webSettings.setAllowUniversalAccessFromFileURLs(true);

            // JavaScript Interface with improved context handling
            webView.addJavascriptInterface(new WebAppInterface(getApplicationContext()), "AndroidInterface");

            // Optimized WebViewClient and WebChromeClient
            webView.setWebChromeClient(new OptimizedWebChromeClient());
            webView.setWebViewClient(new OptimizedWebViewClient());

            // Touch and scroll optimizations
            webView.setScrollBarStyle(View.SCROLLBARS_INSIDE_OVERLAY);
            webView.setOverScrollMode(View.OVER_SCROLL_NEVER);

            loadNotepadHtml();
        } catch (Exception e) {
            Toast.makeText(getApplicationContext(), "Error initializing app: " + e.getMessage(),
						   Toast.LENGTH_LONG).show();
            finish();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        // Re-apply immersive mode when activity resumes
        getWindow().getDecorView().setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_LAYOUT_STABLE
            | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
            | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
            | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
            | View.SYSTEM_UI_FLAG_FULLSCREEN
            | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
    }

    @Override
    protected void onPause() {
        super.onPause();
        // Inject JavaScript to save state when app is paused
        webView.evaluateJavascript("if(typeof saveNotesToStorage === 'function') {saveNotesToStorage();}", null);
    }

    private void loadNotepadHtml() {
        try {
            webView.loadUrl("file:///android_asset/notepad.html");
        } catch (Exception e) {
            Toast.makeText(getApplicationContext(), "Error loading content", Toast.LENGTH_SHORT).show();
        }
    }

    /**
     * Optimized JavaScript Interface for communication
     */
    private static class WebAppInterface {
        private final Context mContext;

        WebAppInterface(Context context) {
            mContext = context;
        }

        @JavascriptInterface
        public void showToast(String message) {
            Toast.makeText(mContext, message, Toast.LENGTH_SHORT).show();
        }
    }

    /**
     * Optimized WebChromeClient for better performance
     */
    private static class OptimizedWebChromeClient extends WebChromeClient {
        // Override methods as needed
    }

    /**
     * Optimized WebViewClient for smoother rendering
     */
    private static class OptimizedWebViewClient extends WebViewClient {
        @Override
        public boolean shouldOverrideUrlLoading(WebView view, String url) {
            view.loadUrl(url);
            return true;
        }

        @Override
        public void onPageFinished(WebView view, String url) {
            super.onPageFinished(view, url);
            // Force hardware rendering after page load for maximum performance
            view.setLayerType(View.LAYER_TYPE_HARDWARE, null);
        }
    }
}
